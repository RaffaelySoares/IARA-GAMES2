function filtrar(categoria) {
const jogos = document.querySelectorAll('.jogo');

jogos.forEach(jogo => {
    jogo.style.display =
    categoria === 'todos' || jogo.dataset.categoria === categoria
    ? 'block'
    : 'none';
});
}

function abrirModal(titulo, descricao) {
document.getElementById('modalTitulo').innerText = titulo;
document.getElementById('modalDescricao').innerText = descricao;

new bootstrap.Modal(document.getElementById('modalJogo')).show();
}
